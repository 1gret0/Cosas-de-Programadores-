import express from "express"
import {dirname, join} from "path" 
import {fileURLToPath} from "url"

import indexroutes from "./routes/routes.js"

const app = express()

const __dirname = dirname(fileURLToPath(import.meta.url))



app.set("views", join(__dirname, 'views'))
app.set("view engine","ejs")
app.use(indexroutes)

//Estilos
app.use(express.static(join(__dirname, "Static")))


// Inicia el servidor en el puerto 3000
app.listen(3000)
console.log("Server is listening on port",3000)